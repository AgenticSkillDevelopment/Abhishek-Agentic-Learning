import setuptools

_version_ = "0.0.0"

ORGANIZATION_NAME = "witty-iot"
REPO_NAME = "witty-iot-human-action-recognition"
AUTHOR_USER_NAME = "sahilv05-witty"
SRC_REPO = "core"
AUTHOR_EMAIL = "sahil.verma@wittybrains.com"

setuptools.setup(
    name=SRC_REPO,
    version=_version_,
    author=AUTHOR_USER_NAME,
    author_email=AUTHOR_EMAIL,
    description="A small human action detection python package.",
    long_description="",
    long_description_content_type="text/markdown",
    url=f"https://github.com/{ORGANIZATION_NAME}/{AUTHOR_USER_NAME}/{REPO_NAME}",
    project_urls={
        "Bug Tracker": f"https://github.com/{ORGANIZATION_NAME}/{AUTHOR_USER_NAME}/{REPO_NAME}/issues",
    },
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    install_requires=[
        "opencv-python==4.11.0.86",
        "numpy",
        "tensorflow==2.18.0",
        "tf2onnx",
        "onnxruntime",
        "gunicorn"
    ],
    include_package_data=True,
    python_requires=">=3.6",
)
