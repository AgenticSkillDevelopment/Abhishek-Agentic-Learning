import os
import requests
import tensorflow as tf
import tf2onnx
from core.monitor import rtsp_detection

def main():
    # === Constants ===
    MODEL_API_URL = "http://192.168.1.23:5500/external/download_model"  # 🔁 Replace this with your actual API
    LOCAL_DIR = "downloaded_model"
    KERAS_MODEL_PATH = os.path.join(LOCAL_DIR, "model.keras")
    ONNX_MODEL_PATH = os.path.join(LOCAL_DIR, "model.onnx")
    RTSP_URL = "rtsp://192.168.1.105:1935/Human-Recognition/obs-studio"

    # === 1. Create local directory ===
    os.makedirs(LOCAL_DIR, exist_ok=True)

    # === 2. Download the model from API ===
    print("Downloading model from API...")
    try:
        response = requests.get(MODEL_API_URL)
        response.raise_for_status()
        with open(KERAS_MODEL_PATH, "wb") as f:
            f.write(response.content)
        print(f"Model saved to {KERAS_MODEL_PATH}")
    except requests.RequestException as e:
        print(f"Failed to download model: {e}")
        exit(1)

    # === 3. Load the Keras model ===
    print("Loading Keras model...")
    try:
        keras_model = tf.keras.models.load_model(KERAS_MODEL_PATH)
    except Exception as e:
        print(f"Error loading model: {e}")
        exit(1)

    # === 4. Patch output names for Sequential model (optional) ===
    if isinstance(keras_model, tf.keras.Sequential):
        keras_model.output_names = ['output']

    # === 5. Convert to ONNX ===
    print("Converting to ONNX format...")
    input_shape = keras_model.input_shape
    input_signature = [tf.TensorSpec([None] + list(input_shape[1:]), tf.float32, name="input")]

    try:
        onnx_model, _ = tf2onnx.convert.from_keras(
            keras_model,
            input_signature=input_signature
        )
    except Exception as e:
        print(f"Failed to convert to ONNX: {e}")
        exit(1)

    # === 6. Save ONNX model ===
    with open(ONNX_MODEL_PATH, "wb") as f:
        f.write(onnx_model.SerializeToString())
    print(f"ONNX model saved to {ONNX_MODEL_PATH}")

    print("\n=== Starting video monitoring/streaming ===")
    rtsp_detection(RTSP_URL, ONNX_MODEL_PATH)
    # rtsp_detection(0, ONNX_MODEL_PATH)

if __name__ == "__main__":
    print("Starting Human Action Recognition Pipeline\n")
    main()


