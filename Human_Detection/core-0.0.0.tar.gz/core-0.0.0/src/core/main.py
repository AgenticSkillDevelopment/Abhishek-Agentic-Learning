import os
from core.pipeline.create_dir import create_model_dir
from core.pipeline.download_model import download_model
from core.pipeline.load_keras_model import load_keras_model
from core.pipeline.convert_to_onnx import convert_to_onnx
from core.pipeline.save_onnx_model import save_onnx_model
from core.pipeline.start_detection import start_detection

DOWNLOAD_MODEL_VERSION = "7"
# MODEL_API_DOMAIN = "192.168.1.23"
MODEL_API_DOMAIN = "127.0.0.1"
MODEL_API_URL = f"http://{MODEL_API_DOMAIN}:5500/external/download_model?model_version={DOWNLOAD_MODEL_VERSION}"
LOCAL_DIR = "downloaded_model" 
KERAS_MODEL_PATH = os.path.join(LOCAL_DIR, "model.keras")
ONNX_MODEL_PATH = os.path.join(LOCAL_DIR, "model.onnx")
TEST_RTSP_URL = "rtsp://192.168.1.105:1935/Human-Recognition/obs-studio"


def main(rtsp_url):
    print("Creating model directory")
    create_model_dir(LOCAL_DIR)

    print("Downloading Onnx model from API")
    download_model(MODEL_API_URL, ONNX_MODEL_PATH)

    print("Starting RTSP detection pipeline")
    start_detection(rtsp_url, ONNX_MODEL_PATH)


if __name__ == "__main__":
    print("Starting Human Action Recognition Pipeline\n")
    main("")
    print("\n Pipeline execution completed.")
