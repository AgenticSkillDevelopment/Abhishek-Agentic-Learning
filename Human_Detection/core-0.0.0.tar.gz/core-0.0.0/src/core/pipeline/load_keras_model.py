import tensorflow as tf

def load_keras_model(path):
    print("[📦] Loading Keras model...")
    try:
        model = tf.keras.models.load_model(path)
        print("[✔] Keras model loaded successfully")
        return model
    except Exception as e:
        raise RuntimeError(f"Error loading Keras model: {e}")
