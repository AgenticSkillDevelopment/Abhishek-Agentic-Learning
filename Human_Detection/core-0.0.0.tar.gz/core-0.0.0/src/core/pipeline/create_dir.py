import os

def create_model_dir(path):
    os.makedirs(path, exist_ok=True)
    print(f"[✔] Created/verified directory: {path}")
