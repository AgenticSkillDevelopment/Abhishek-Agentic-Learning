from core.monitor import rtsp_detection

def start_detection(rtsp_url, model_path):
    print("[📹] Starting video monitoring...")
    rtsp_detection(rtsp_url, model_path)
