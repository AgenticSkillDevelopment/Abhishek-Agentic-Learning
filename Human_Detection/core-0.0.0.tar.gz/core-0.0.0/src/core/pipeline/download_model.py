import requests

def download_model(url, save_path):
    print("[⏬] Downloading model from API...")
    try:
        response = requests.get(url)
        response.raise_for_status()
        with open(save_path, "wb") as f:
            f.write(response.content)
        print(f"[✔] Model downloaded to {save_path}")
    except requests.RequestException as e:
        raise RuntimeError(f"Failed to download model: {e}")
