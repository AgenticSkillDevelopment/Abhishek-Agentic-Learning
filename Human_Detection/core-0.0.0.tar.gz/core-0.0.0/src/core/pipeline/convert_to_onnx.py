import tf2onnx
import tensorflow as tf

def convert_to_onnx(keras_model):
    print("[🔄] Converting to ONNX format...")
    if isinstance(keras_model, tf.keras.Sequential):
        keras_model.output_names = ['output']  # Optional fix

    input_shape = keras_model.input_shape
    input_signature = [tf.TensorSpec([None] + list(input_shape[1:]), tf.float32, name="input")]

    try:
        onnx_model, _ = tf2onnx.convert.from_keras(keras_model, input_signature=input_signature)
        print("[✔] Model converted to ONNX")
        return onnx_model
    except Exception as e:
        raise RuntimeError(f"ONNX conversion failed: {e}")
