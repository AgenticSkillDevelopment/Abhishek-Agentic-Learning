def save_onnx_model(onnx_model, save_path):
    with open(save_path, "wb") as f:
        f.write(onnx_model.SerializeToString())
    print(f"[💾] ONNX model saved to {save_path}")
