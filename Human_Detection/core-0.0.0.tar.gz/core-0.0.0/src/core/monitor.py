

'''
import os

import cv2
import csv
import time
import numpy as np
import onnxruntime as ort
from datetime import datetime

def rtsp_detection(rtsp_url):
    
    # === Load the ONNX model ===
    onnx_session = ort.InferenceSession("model.onnx")
    input_name = onnx_session.get_inputs()[0].name
    input_shape = onnx_session.get_inputs()[0].shape  # e.g., [None, 20, 64, 64, 3]
    
    # === Class labels ===
    CLASS_LABELS = ['Eating', 'Fighting', 'Talking']
    TARGET_CLASS = 'Fighting'  # Only log this class
    
    # === Webcam Setup ===
    video_capture = cv2.VideoCapture(rtsp_url)
    if not video_capture.isOpened():
        print("Error: Could not open webcam.")
        exit()
    
    # === Frame settings ===
    frame_width = 350
    frame_height = 400
    fps = video_capture.get(cv2.CAP_PROP_FPS) or 20.0
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out_video = cv2.VideoWriter('output_video_with_detections.mp4', fourcc, fps, (frame_width, frame_height))
    
    # === Frame Sequence Logic ===
    frame_sequence = []
    sequence_length = 20
    threshold = 0.5
    
    # === Snapshot & Log Setup ===
    snapshot_dir = 'snapshots'
    log_file = 'snapshot_log.csv'
    os.makedirs(snapshot_dir, exist_ok=True)
    
    # Initialize CSV log file
    if not os.path.exists(log_file):
        with open(log_file, mode='w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Timestamp", "Class", "Confidence", "Snapshot_Path"])
    
    last_detected_class = None
    last_snapshot_time = time.time()
    
    # === Detection Loop ===
    while True:
        ret, frame = video_capture.read()
        if not ret:
            break
    
        frame = cv2.resize(frame, (frame_width, frame_height))
    
        resized_frame = cv2.resize(frame, (64, 64))
        resized_frame = resized_frame / 255.0
        frame_sequence.append(resized_frame)
    
        if len(frame_sequence) == sequence_length:
            input_sequence = np.expand_dims(np.array(frame_sequence), axis=0).astype(np.float32)
    
            # === Run ONNX model prediction ===
            onnx_outputs = onnx_session.run(None, {input_name: input_sequence})
            predictions = onnx_outputs[0]
            predicted_class_index = np.argmax(predictions)
            confidence = predictions[0][predicted_class_index]
            current_class = CLASS_LABELS[predicted_class_index]
    
            if confidence > threshold:
                label = f"{current_class} {confidence:.2f}"
    
                # Draw detection box and label
                x1, y1 = 50, 50
                x2, y2 = frame_width - 50, frame_height - 50
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    
                current_time = time.time()
                time_elapsed = current_time - last_snapshot_time
    
                # === Snapshot & Log only for "Fighting" ===
                if current_class == TARGET_CLASS and (current_class != last_detected_class or time_elapsed >= 20):
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    filename = os.path.join(snapshot_dir, f"{current_class}_{timestamp}.jpg")
                    cv2.imwrite(filename, frame)
                    print(f"[INFO] Snapshot saved: {filename}")
    
                    # Log to CSV
                    with open(log_file, mode='a', newline='') as f:
                        writer = csv.writer(f)
                        writer.writerow([timestamp, current_class, f"{confidence:.2f}", filename])
    
                    last_snapshot_time = current_time
                    last_detected_class = current_class
    
            frame_sequence.pop(0)
    
        out_video.write(frame)
        cv2.imshow("Video Detection", frame)
    
        if cv2.waitKey(1) & 0xFF == 27:
            break
    
    video_capture.release()
    out_video.release()
    cv2.destroyAllWindows()
    print("✅ Output video saved and 'Fighting' snapshots logged.")'''

 
 
 
'''   
import os
import cv2
import csv
import time
import numpy as np
import onnxruntime as ort
from datetime import datetime

def rtsp_detection(rtsp_url, model_path):  # ⬅️ Accept model path as parameter

    # === Load the ONNX model ===
    onnx_session = ort.InferenceSession(model_path)  # ⬅️ Use dynamic model path
    input_name = onnx_session.get_inputs()[0].name
    input_shape = onnx_session.get_inputs()[0].shape  # e.g., [None, 20, 64, 64, 3]

    # === Class labels ===
    CLASS_LABELS = ['Eating', 'Fighting', 'Talking']
    TARGET_CLASS = 'Fighting'  # Only log this class

    # === RTSP Setup ===
    os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;tcp|max_delay;500"  # ⬅️ Improve RTSP stability
    video_capture = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
    if not video_capture.isOpened():
        print("❌ Error: Could not open RTSP stream.")
        exit()

    # === Frame settings ===
    frame_width = 350
    frame_height = 400
    fps = video_capture.get(cv2.CAP_PROP_FPS) or 20.0
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out_video = cv2.VideoWriter('output_video_with_detections.mp4', fourcc, fps, (frame_width, frame_height))

    # === Frame Sequence Logic ===
    frame_sequence = []
    sequence_length = 20
    threshold = 0.5

    # === Snapshot & Log Setup ===
    snapshot_dir = 'snapshots'
    log_file = 'snapshot_log.csv'
    os.makedirs(snapshot_dir, exist_ok=True)

    # Initialize CSV log file
    if not os.path.exists(log_file):
        with open(log_file, mode='w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Timestamp", "Class", "Confidence", "Snapshot_Path"])

    last_detected_class = None
    last_snapshot_time = time.time()

    # === Detection Loop ===
    while True:
        ret, frame = video_capture.read()
        if not ret:
            print("⚠️ Frame read failed. Skipping frame.")
            continue

        frame = cv2.resize(frame, (frame_width, frame_height))

        resized_frame = cv2.resize(frame, (64, 64))
        resized_frame = resized_frame / 255.0
        frame_sequence.append(resized_frame)

        if len(frame_sequence) == sequence_length:
            input_sequence = np.expand_dims(np.array(frame_sequence), axis=0).astype(np.float32)

            # === Run ONNX model prediction ===
            onnx_outputs = onnx_session.run(None, {input_name: input_sequence})
            predictions = onnx_outputs[0]
            predicted_class_index = np.argmax(predictions)
            confidence = predictions[0][predicted_class_index]
            current_class = CLASS_LABELS[predicted_class_index]

            if confidence > threshold:
                label = f"{current_class} {confidence:.2f}"

                # Draw detection box and label
                x1, y1 = 50, 50
                x2, y2 = frame_width - 50, frame_height - 50
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                current_time = time.time()
                time_elapsed = current_time - last_snapshot_time

                # === Snapshot & Log only for "Fighting" ===
                if current_class == TARGET_CLASS and (current_class != last_detected_class or time_elapsed >= 20):
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    filename = os.path.join(snapshot_dir, f"{current_class}_{timestamp}.jpg")
                    cv2.imwrite(filename, frame)
                    print(f"[INFO] Snapshot saved: {filename}")

                    # Log to CSV
                    with open(log_file, mode='a', newline='') as f:
                        writer = csv.writer(f)
                        writer.writerow([timestamp, current_class, f"{confidence:.2f}", filename])

                    last_snapshot_time = current_time
                    last_detected_class = current_class

            frame_sequence.pop(0)

        out_video.write(frame)
        cv2.imshow("Video Detection", frame)

        if cv2.waitKey(1) & 0xFF == 27:
            break

    video_capture.release()
    out_video.release()
    cv2.destroyAllWindows()
    print("✅ Output video saved and 'Fighting' snapshots logged.")









<<<<<<< HEAD
video_capture.release()
out_video.release()
cv2.destroyAllWindows()
print("✅ Output video saved and 'Fighting' snapshots logged.")'''

import os
import cv2
import csv
import time
import numpy as np
import onnxruntime as ort
from datetime import datetime
 
def rtsp_detection(rtsp_url, model_path):  # ⬅️ Accept model path as parameter
 
    # === Load the ONNX model ===
    onnx_session = ort.InferenceSession(model_path)  # ⬅️ Use dynamic model path
    input_name = onnx_session.get_inputs()[0].name
    input_shape = onnx_session.get_inputs()[0].shape  # e.g., [None, 20, 64, 64, 3]
 
    # === Class labels ===
    CLASS_LABELS = ['Eating', 'Fighting', 'Talking']
    TARGET_CLASS = 'Fighting'  # Only log this class
 
    # === RTSP Setup ===
    os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;tcp|max_delay;500"  # ⬅️ Improve RTSP stability
    video_capture = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
    if not video_capture.isOpened():
        print("❌ Error: Could not open RTSP stream.")
        exit()
 
    # === Frame settings ===
    frame_width = 350
    frame_height = 400
    fps = video_capture.get(cv2.CAP_PROP_FPS) or 20.0
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out_video = cv2.VideoWriter('output_video_with_detections.mp4', fourcc, fps, (frame_width, frame_height))
 
    # === Frame Sequence Logic ===
    frame_sequence = []
    sequence_length = 20
    threshold = 0.5
 
    # === Snapshot & Log Setup ===
    snapshot_dir = 'snapshots'
    log_file = 'snapshot_log.csv'
    os.makedirs(snapshot_dir, exist_ok=True)
 
    # Initialize CSV log file
    if not os.path.exists(log_file):
        with open(log_file, mode='w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Timestamp", "Class", "Confidence", "Snapshot_Path"])
 
    last_detected_class = None
    last_snapshot_time = time.time()
 
    # === Detection Loop ===
    while True:
        ret, frame = video_capture.read()
        if not ret:
            print("⚠️ Frame read failed. Skipping frame.")
            continue
 
        frame = cv2.resize(frame, (frame_width, frame_height))
 
        resized_frame = cv2.resize(frame, (64, 64))
        resized_frame = resized_frame / 255.0
        frame_sequence.append(resized_frame)
 
        if len(frame_sequence) == sequence_length:
            input_sequence = np.expand_dims(np.array(frame_sequence), axis=0).astype(np.float32)
 
            # === Run ONNX model prediction ===
            onnx_outputs = onnx_session.run(None, {input_name: input_sequence})
            predictions = onnx_outputs[0]
            predicted_class_index = np.argmax(predictions)
            confidence = predictions[0][predicted_class_index]
            current_class = CLASS_LABELS[predicted_class_index]
 
            if confidence > threshold:
                label = f"{current_class} {confidence:.2f}"
 
                # Draw detection box and label
                x1, y1 = 50, 50
                x2, y2 = frame_width - 50, frame_height - 50
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
 
                current_time = time.time()
                time_elapsed = current_time - last_snapshot_time
 
                # === Snapshot & Log only for "Fighting" ===
                if current_class == TARGET_CLASS and (current_class != last_detected_class or time_elapsed >= 20):
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    filename = os.path.join(snapshot_dir, f"{current_class}_{timestamp}.jpg")
                    cv2.imwrite(filename, frame)
                    print(f"[INFO] Snapshot saved: {filename}")
 
                    # Log to CSV
                    with open(log_file, mode='a', newline='') as f:
                        writer = csv.writer(f)
                        writer.writerow([timestamp, current_class, f"{confidence:.2f}", filename])
 
                    last_snapshot_time = current_time
                    last_detected_class = current_class
 
            frame_sequence.pop(0)
 
        out_video.write(frame)
        cv2.imshow("Video Detection", frame)
 
        if cv2.waitKey(1) & 0xFF == 27:
            break
 
    video_capture.release()
    out_video.release()
    cv2.destroyAllWindows()
    print("✅ Output video saved and 'Fighting' snapshots logged.")

